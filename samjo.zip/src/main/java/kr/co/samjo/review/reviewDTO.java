package kr.co.samjo.review;

public class reviewDTO {
	private int review_no;			
    private String review_user_id;			
    private String review_res_no;				
    private String  review_code;			
    private int review_asterion;			
    private String review_date;				
    private String review_content;
    
	public int getReview_no() {
		return review_no;
	}
	public void setReview_no(int review_no) {
		this.review_no = review_no;
	}
	public String getReview_user_id() {
		return review_user_id;
	}
	public void setReview_user_id(String review_user_id) {
		this.review_user_id = review_user_id;
	}
	public String getReview_res_no() {
		return review_res_no;
	}
	public void setReview_res_no(String review_res_no) {
		this.review_res_no = review_res_no;
	}
	public String getReview_code() {
		return review_code;
	}
	public void setReview_code(String review_code) {
		this.review_code = review_code;
	}
	public int getReview_asterion() {
		return review_asterion;
	}
	public void setReview_asterion(int review_asterion) {
		this.review_asterion = review_asterion;
	}
	public String getReview_date() {
		return review_date;
	}
	public void setReview_date(String review_date) {
		this.review_date = review_date;
	}
	public String getReview_content() {
		return review_content;
	}
	public void setReview_content(String review_content) {
		this.review_content = review_content;
	}
    
    
}
