package kr.co.samjo.product.maszip;

public class MaszipDAO {

}
