package kr.co.samjo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SamjoApplicationTests {

	@Test
	void contextLoads() {
	}

}
