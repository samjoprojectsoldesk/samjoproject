package kr.co.samjo.product.sooksoproduct;

public class SooksoProductDAO {

}
