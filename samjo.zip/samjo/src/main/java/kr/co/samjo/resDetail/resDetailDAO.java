package kr.co.samjo.resDetail;

public class resDetailDAO {

}
