package kr.co.samjo.res;

public class resDAO {

}
